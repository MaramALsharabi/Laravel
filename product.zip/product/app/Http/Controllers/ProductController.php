<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function show()
    {
        return view('pages.show');
    }

    public function insert(Request $request)
    {
        $obj=new Product;
        $obj->name=$request->name;
        $obj->details=$request->details;
        $obj->price=$request->price;
        $obj->save();
        return response("added successfully");
    }

}
