<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="{{route('insertion')}}" method="post">
    @csrf
    <label for="">Name</label><br>
    <input type="text" name='name'><br>
    <label for="">Details</label><br>
    <input type="text" name='details'><br>
    <label for="">Price</label><br>
    <input type="text" name='price'><br><br>
    <button>add</button>
    </form>
</body>
</html>